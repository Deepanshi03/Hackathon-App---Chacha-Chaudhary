package com.example.joke

data class DataModel(

    var query: String,
    var response:String

):java.io.Serializable
